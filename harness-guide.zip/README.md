# 从零理解 LLM Agent：Harness 实战教程

> **基于 learn-claude-code 课程 + mini-agent 项目实战**
>
> 作者：常雨 & 瑞士军刀 🔧
>
> 版本：v2.0 | 2026-04-06
>
> 代码仓库：https://github.com/changyu496/mini-agent
>
> 代码快照：ch02~ch10 九个可运行版本 zip

---

## 目录

1. [前言：Agent 到底是什么](#前言)
2. [Chapter 2: Agent Loop — 一切的开始](#chapter-2)
3. [Chapter 3: 工具系统 — Agent 的手和脚](#chapter-3)
4. [Chapter 4: Todo 系统 — Agent 的记事本](#chapter-4)
5. [Chapter 5: SubAgent — 一次性的子任务](#chapter-5)
6. [Chapter 6: Skill 懒加载 — 按需加载能力](#chapter-6)
7. [Chapter 7: 上下文压缩 — 控制 token 成本](#chapter-7)
8. [Chapter 8: Task 持久化 — 跨会话的记忆](#chapter-8)
9. [Chapter 9: 后台任务 — 不卡住的异步执行](#chapter-9)
10. [Chapter 10: 多 Agent 团队 — 协作与通信](#chapter-10)
11. [Chapter 11: 多 Agent 架构总结](#chapter-11)
12. [附录：术语对照表](#appendix)

---

## 前言：Agent 到底是什么 <a name="前言"></a>

2024 年到 2025 年，AI Agent 是一个被热炒的概念。打开任何一篇技术博客，都在说"Agent"、"Harness"、"Multi-Agent"、"SubAgent"……但真正讲清楚**它们是什么、为什么需要、怎么落地**的文章，凤毛麟角。

大多数教程要么讲得太浅（"Agent 就是能调用工具的 AI"），要么讲得太玄（"Agent 是自主智能体"），缺少从零构建、一步步迭代的真实案例。

### 本文的目标

**用代码讲清楚 Agent Harness 的每个概念**。我们从零实现一个 Java 版本的 mini-agent 项目，每一章解决一个问题，每一章都有真实可运行的代码。

### 核心观点

> **Agent = 模型 + 工程基础设施（Harness）**
>
> 模型是大脑，Harness 是身体。
>
> 没有 Harness 的模型只是 API 调用，有了 Harness 才能真正"做事情"。

这个观点来自 learn-claude-code 课程的核心洞察：做 Agent 应用，**90% 的工作在 Harness 工程侧**，模型只需要负责"决策"。

### 什么是 Harness

Harness（载具）是让 Agent 循环跑起来的**全部工程代码**：

| 层次 | 内容 | 作用 |
|------|------|------|
| **LLM 调用层** | HTTP 客户端、请求体构建、响应解析 | 和模型通信 |
| **工具系统** | Schema 定义、Handler 执行、Dispatcher 分发 | 让 Agent 能做事 |
| **消息管理层** | 历史消息、上下文长度、压缩策略 | 控制 token 成本 |
| **记忆系统** | 短期记忆、长期记忆、Skill 懒加载 | 持久化和复用 |

模型本身不知道自己在做 Agent，它只是在做"文本补全"。是 Harness 赋予了它"能做事"的能力。

---

## Chapter 2: Agent Loop — 一切的开始 <a name="chapter-2"></a>

📦 [mini-agent-02.zip](./mini-agent-02.zip) | commit: `b0730cd`

### 这一章解决什么问题

**如何让大模型持续工作直到任务完成？**

用户说"帮我写一个冒泡排序"，大模型返回一段代码——这只是"一次调用"。但真实场景中，大模型需要反复思考、反复行动。这需要一个**循环**。

### 核心代码

```java
while (true) {
    // 1. 调用大模型
    OpenAIResponse resp = client.call(messages, tools);
    Message assistantMsg = resp.getChoices().get(0).getMessage();
    messages.add(assistantMsg);

    // 2. 检查是否结束
    if (!"tool_calls".equals(resp.getChoices().get(0).getFinishReason())) {
        return assistantMsg.getContent();  // 结束
    }

    // 3. 执行工具调用
    for (ToolCall tc : assistantMsg.getToolCalls()) {
        String result = callTool(tc);
        messages.add(toolResultMessage(tc, result));
    }
    // 4. 循环继续
}
```

### 三个关键点

**① finish_reason 判断**

大模型返回时，有一个 `finish_reason` 字段：
- `"tool_calls"` → 大模型要求调用工具，继续循环
- 其他值 → 大模型直接回答了，循环结束

如果不判断这个，模型永远只会说"我需要调用工具"，不会给出最终答案。

**② 消息历史累积**

每次调用后，`assistantMsg` 和 `toolResultMsg` 都要加到 `messages` 里。这样下一轮循环时，大模型能看到完整上下文。

**③ 工具结果格式**

```java
private Message toolResultMessage(ToolCall tc, String result) {
    Message toolMessage = new Message();
    toolMessage.setRole("tool");
    toolMessage.setToolCallId(tc.getId());
    toolMessage.setName(tc.getFunction().getName());
    toolMessage.setContent(result);
    return toolMessage;
}
```

大模型需要知道"哪个工具调用返回了什么"，`tool_call_id` 和 `name` 字段是必须的。

### 踩过的坑

**坑1：忘记把工具结果加回历史**

工具执行了，但忘了 `messages.add(toolResultMessage(...))`，下一轮大模型就"失忆"了。

**坑2：工具结果没有 `name` 字段**

某些 API 响应里工具结果不包含 `name`，大模型会困惑"这是哪个工具的结果"。需要在构造 Message 时手动补上。

### 本章学到了什么

- **Agent Loop = while(true) + finish_reason 判断**
- 消息历史是上下文的来源，必须正确累积
- 工具结果要包含 `tool_call_id` 和 `name`

---

## Chapter 3: 工具系统 — Agent 的手和脚 <a name="chapter-3"></a>

📦 [mini-agent-03.zip](./mini-agent-03.zip) | commit: `2cf3474`

### 这一章解决什么问题

**如何让 Agent 调用各种不同的工具（读文件、写文件、搜索、执行命令）？**

如果只有 Agent Loop，Agent 只能"想"，不能"做"。工具系统让 Agent 真正能操作外部世界。

### 核心设计：ToolHandler 接口 + Dispatcher

```java
// 工具处理器接口
public interface ToolHandler {
    String execute(String argJson, String functionName);
}

// 每个工具对应一个 Handler
public class ReadFileHandler implements ToolHandler {
    @Override
    public String execute(String argJson, String functionName) {
        Map<String, String> args = parseArgs(argJson);
        return safeReadFile(args.get("path"));
    }
}

// 分发
Map<String, ToolHandler> dispatcher = new HashMap<>();
dispatcher.put("read_file", new ReadFileHandler());
dispatcher.put("write_file", new WriteFileHandler());

// 调用
public String callTool(ToolCall toolCall) {
    String functionName = toolCall.getFunction().getName();
    ToolHandler handler = dispatcher.get(functionName);
    if (handler == null) return "未知工具: " + functionName;
    return handler.execute(toolCall.getFunction().getArguments(), functionName);
}
```

### Schema 和 Handler 的区别

- **Schema**：给大模型看的"合同"（叫什么、参数是什么）
- **Handler**：工程师写的执行代码

两者独立，修改一方不影响另一方。

### 踩过的坑

- handler 返回 null → 大模型收到 null 字符串导致推理出错
- args 解析失败但不报错 → 后来在 catch 里打日志
- 路径安全性 → 后来限制了路径在 workspace 内

### 本章学到了什么

- **工具 = Schema（给模型看）+ Handler（给工程师写）**
- Dispatcher 是工具调用的中枢，通过名字路由到对应 Handler
- 所有 handler 返回值都要保证非 null

---

## Chapter 4: Todo 系统 — Agent 的记事本 <a name="chapter-4"></a>

📦 [mini-agent-04.zip](./mini-agent-04.zip) | commit: `3413f8d`

### 这一章解决什么问题

**Agent 做复杂任务时，如何记录进度，不每次都从头开始？**

### 关键洞察：工具不一定是"做事的"

```java
public String execute(String argJson, String functionName) {
    return switch (functionName) {
        case "task_create" -> taskCreate(args);
        case "task_update" -> taskUpdate(args);
        case "task_list" -> taskList(args);
        default -> "未知操作: " + functionName;
    };
}
```

TodoHandler 根本不操作外部系统，只操作内存中的状态。这说明：**工具是一种接口模式**，核心是"给大模型暴露一个可调用的动作"。

### 踩过的坑

- 并发问题 → 使用 `ConcurrentHashMap`
- 状态没有持久化 → 在 Chapter 8 中解决

### 本章学到了什么

- **工具可以操作内部状态**，不一定调用外部系统
- `switch` 分发是个好模式，一个 Handler 可以处理多个子操作

---

## Chapter 5: SubAgent — 一次性的子任务 <a name="chapter-5"></a>

📦 [mini-agent-05.zip](./mini-agent-05.zip) | commit: `b3ff497`

### 这一章解决什么问题

**主 Agent 在工作过程中，有时候需要调用一个完全独立的 Agent 来完成任务，但不能卡住。**

比如主 Agent 说"帮我搜索科举制度的历史"——搜索本身很复杂，需要多次调用搜索工具、读文件工具。但主 Agent 不能卡在这里。

### 核心方案：把子任务交给 SubAgent

```
Main Agent: "帮我研究" → SubAgent: 搜索→读文件→写笔记→返回
```

SubAgent 是一个**独立的 Agent Loop**，有自己的 messages、tools、轮次限制，执行完毕后把结果返回给主 Agent。

```java
public String runSubAgent(String prompt) {
    List<Message> subMessages = new ArrayList<>();
    subMessages.add(new Message("system", "你是研究助手..."));
    subMessages.add(new Message("user", prompt));
    return AgentRunner.run(client, subMessages, regBasicTool(), executor, 30);
}
```

### SubAgent vs 主 Agent

| | 主 Agent | SubAgent |
|--|---------|---------|
| 工具集合 | 完整 | 受限（不需要 sub_agent 本身） |
| 消息列表 | historyMessages | 独立的 subMessages |
| 轮次限制 | 无 | 30 轮上限 |

### 踩过的坑

- **消息列表混用**：两个列表必须完全隔离
- **SubAgent 调用了 sub_agent**：导致递归死循环，所以用 `regBasicTool()`

### 本章学到了什么

- **SubAgent = 独立的 Agent Loop**，有自己的 messages、tools、轮次限制
- 主 Agent 和 SubAgent 的消息历史**完全隔离**

---

## Chapter 6: Skill 懒加载 — 按需加载能力 <a name="chapter-6"></a>

📦 [mini-agent-06.zip](./mini-agent-06.zip) | commit: `22fd9cb`

### 这一章解决什么问题

**工具越来越多，全部加载会让请求变慢，但大多数时候用户只需要其中几个。**

### 核心方案：需要时才加载

```java
public static List<ToolDefinition> loadSkill(String skillName) {
    Path skillPath = Paths.get("skills", skillName, "SKILL.md");
    String content = Files.readString(skillPath);
    return parseSkillFile(content);  // 从 markdown 解析工具定义
}
```

### 关键洞察

**工具本身也是数据**。可以存文件里、数据库里、甚至从网络加载，不需要硬编码。这让系统变得可扩展。

### 踩过的坑

- SKILL.md 写得模糊，大模型不知道什么时候该用
- 懒加载后没有缓存，每次都重新读文件 → 后来加了缓存

### 本章学到了什么

- **Harness 不只是"跑起来"，还包括"什么时候加载什么"的决策逻辑**
- 懒加载让系统可扩展，但需要考虑缓存

---

## Chapter 7: 上下文压缩 — 控制 token 成本 <a name="chapter-7"></a>

📦 [mini-agent-07.zip](./mini-agent-07.zip) | commit: `d7518f1`

### 这一章解决什么问题

**对话历史越来越长，token 消耗越来越多，大模型开始变慢。**

### 核心观察

对话历史中，大部分内容是**工具执行记录**。大模型真正需要知道的是"用了哪些工具、结果是什么"，而不是每次工具调用的完整输入输出。

### 方案：超过 N 个工具结果后，压缩内容

```java
private static void microCompact(List<Message> messages) {
    int toolCount = 0;
    for (int i = messages.size() - 1; i >= 0; i--) {
        Message msg = messages.get(i);
        if ("tool".equals(msg.getRole())) {
            toolCount++;
            if (toolCount > 3) {
                msg.setContent("[Previously used {" + msg.getName() + "}]");
            }
        }
    }
}
```

**从后往前数 3 个保留完整内容**，之前的都压缩。

### 踩过的坑

- 第一轮就压缩 → 丢失所有上下文（阈值设为 3 解决）
- 压缩时机不对 → 先添加结果再压缩

### 本章学到了什么

- **上下文压缩的本质：用信息换 token**
- 压缩时机很重要，太早压缩丢失信息，太晚浪费 token

---

## Chapter 8: Task 持久化 — 跨会话的记忆 <a name="chapter-8"></a>

📦 [mini-agent-08.zip](./mini-agent-08.zip) | commit: `8cc8aa9`

### 这一章解决什么问题

**TodoManager 里的任务只存在于内存，程序重启就丢了。**

### 核心方案：TaskManager + 磁盘存储

```java
private void loadTasks() {
    if (Files.exists(taskFile)) {
        String json = Files.readString(taskFile);
        Task[] arr = new ObjectMapper().readValue(json, Task[].class);
        for (Task t : arr) tasks.put(t.getId(), t);
    }
}

public void saveTasks() {
    String json = new ObjectMapper().writeValueAsString(tasks.values());
    Files.writeString(taskFile, json);
}
```

### 踩过的坑

- 并发写入冲突 → 加 synchronized
- 磁盘 I/O 性能 → 后来改为定期或退出时写入

### 本章学到了什么

- **状态持久化是 Harness 的重要组成部分**
- Agent 不只是处理即时请求，还要能记住"之前在做什么"

---

## Chapter 9: 后台任务 — 不卡住的异步执行 <a name="chapter-9"></a>

📦 [mini-agent-09.zip](./mini-agent-09.zip) | commit: `7ec3dfa`

### 这一章解决什么问题

**SubAgent 是同步的：调用 → 等完成 → 返回。如果子任务很慢，主 Agent 就卡住了。**

### 核心方案：后台提交 + 通知注入

```java
// 1. 提交后台任务，立即返回 jobId
public String submit(String type, String description, Callable<String> job) {
    String jobId = UUID.randomUUID().toString();
    executor.submit(() -> {
        String result = job.call();      // 后台执行
        jobInfo.setResult(result);       // 写入结果
        jobNotificationQueue.add(result); // 通知队列
    });
    return "jobId: " + jobId;           // 立即返回
}

// 2. 每次 Agent Loop 前注入通知
public static void injectBackgroundNotifications(List<Message> messages) {
    var notifications = BackgroundManger.getInstance().drainNotifications();
    if (!notifications.isEmpty()) {
        messages.add(new Message("user", "<background-results>\n" + notifications + "\n</background-results>"));
    }
}
```

### Callable vs Runnable

- `Runnable.run()` 返回 void，无法获取结果
- `Callable.call()` 返回 T，可以获取真实结果

### SubAgent vs 后台任务

| | SubAgent (Chapter 5) | 后台任务 (Chapter 9) |
|--|--|--|
| 等待方式 | 同步等完成 | 不等，完成后通知 |
| 适用场景 | 需要结果才能继续 | 结果可以晚点来 |

### 踩过的坑

- **用 Runnable 而不是 Callable**：必须用 `Callable<String>` 才能捕获真实结果
- **ArrayDeque 不是线程安全**：用 `ConcurrentLinkedQueue`
- **通知注入时机**：必须在 LLM 调用之前，否则模型看不到

### 本章学到了什么

- **异步 = 提交 + 不等 + 通知机制**
- `ConcurrentLinkedQueue.poll()` 是非阻塞的，不会等

---

## Chapter 10: 多 Agent 团队 — 协作与通信 <a name="chapter-10"></a>

📦 [mini-agent-10.zip](./mini-agent-10.zip) | commit: `9065940`

### 这一章解决什么问题

SubAgent 是一次性的，真实场景需要：
- 多个 Agent **同时工作**
- Agent 之间**互相通信**
- Agent **长期存在**，不是执行完就销毁

### 核心方案：MessageBus + TeammateManager

```
.team/
  config.json          ← 谁在、什么状态
  inbox/
    alice.jsonl        ← alice 的消息队列
    bob.jsonl
    lead.jsonl        ← 主 Agent 的消息队列
```

### MessageBus：基于文件的进程间通信

```java
public class MessageBus {
    private final Path inboxDir;

    // 发消息：追加到目标收件箱
    public String send(String sender, String to, String content, String msgType) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("type", msgType);
        msg.put("from", sender);
        msg.put("content", content);
        msg.put("timestamp", System.currentTimeMillis());

        Path inboxPath = inboxDir.resolve(to + ".jsonl");
        Files.writeString(inboxPath,
            objectMapper.writeValueAsString(msg) + "\n",
            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        return "Sent to " + to;
    }

    // 读消息：破坏性读取（读完清空，避免重复处理）
    public List<Map<String, Object>> readInbox(String name) {
        // 读文件 → 转成 List → 清空文件 → 返回
        // 读完后必须清空，否则下次会重复处理
    }

    // 广播
    public String broadcast(String sender, String content, List<String> teammates) {
        for (String name : teammates) {
            if (!name.equals(sender)) {
                send(sender, name, content, "broadcast");
            }
        }
    }
}
```

**为什么要破坏性读取？**

如果读完后不 clear，下次 loop 又读到同一批消息，会重复处理、死循环。

### TeammateManager：持久化 Agent 线程管理

```java
public class TeammateManager {

    // 两个 tracker（s10 新增）
    private static final Map<String, Map<String, Object>> shutdownRequests = new ConcurrentHashMap<>();
    private static final Map<String, Map<String, Object>> planRequests = new ConcurrentHashMap<>();

    public String spawn(String name, String role, String prompt) {
        // 1. 检查是否已存在
        // 2. 更新 config.json
        // 3. 启动新线程
        Thread thread = new Thread(() -> teammateLoop(name, role, prompt));
        threads.put(name, thread);
        thread.start();
        return "Spawned " + name;
    }

    private void teammateLoop(String name, String role, String prompt) {
        List<Message> messages = new ArrayList<>();
        messages.add(new Message("system",
            "你是 " + name + "，角色是 " + role + "。完成任务后，使用 send_message 工具把结果发给 lead。"));
        messages.add(new Message("user", prompt));

        AtomicBoolean shouldExit = new AtomicBoolean(false);
        int maxRound = 50;
        int round = 0;

        while (round < maxRound && !shouldExit.get()) {
            // 1. 检查收件箱
            List<Map<String, Object>> inbox = messageBus.readInbox(name);
            for (Map<String, Object> msg : inbox) {
                messages.add(new Message("user", objectMapper.writeValueAsString(msg)));

                // 2. 处理 shutdown_request（s10 新增）
                if ("shutdown_request".equals(msg.get("type"))) {
                    String requestId = String.valueOf(msg.get("request_id"));
                    Map<String, Object> req = new HashMap<>();
                    req.put("status", "approved");
                    shutdownRequests.put(requestId, req);
                    Map<String, Object> extra = new HashMap<>();
                    extra.put("request_id", requestId);
                    extra.put("approve", true);
                    messageBus.send(name, "lead", "Shutting down gracefully.",
                        "shutdown_response", extra);
                    shouldExit.set(true);
                    break;
                }
            }

            if (shouldExit.get()) break;

            // 3. 调用 LLM
            String result = AgentRunner.run(client, messages, buildTeammateTools(),
                getTeammateExecutor(name, shouldExit), null, maxRound - round);

            // 4. 任务完成、无新消息则退出
            if (result != null && !result.isEmpty() && messageBus.readInbox(name).isEmpty()) {
                break;
            }
            round++;
        }

        // 5. 更新状态
        Member member = findMember(name);
        if (member != null) {
            member.setStatus("idle");
            saveConfig();
        }
    }
}
```

### Teammate 可用的工具

```java
public static List<Map<String, Object>> buildTeammateTools() {
    // read_file, write_file, bash, send_message
    // shutdown_response, plan_approve（s10 新增）
}
```

### AgentRunner 提取

为了主 Agent、SubAgent、Teammate 共用一套 LLM 调用逻辑，把 Agent Loop 提取成独立类：

```java
public class AgentRunner {
    // 无限制版本（主 Agent）
    public static void runForever(...) { while (true) { ... } }

    // 限制轮次版本（SubAgent / Teammate）
    public static String run(..., int maxRound) {
        int round = 0;
        while (round < maxRound) { ... }
    }
}
```

通过两个接口注入不同策略：
- **ToolExecutor**：主 Agent 用 dispatcher，Teammate 用 switch
- **NotificationHandler**：主 Agent 注入后台通知，Teammate 传 null

### s10 新增：两个协议（Protocols）

**协议1：Shutdown**

```
Lead                    Teammate
  | shutdown_request →  |
  |                     | 收到 → 自动回复
  | ← shutdown_response |
```

实现：teammate 收到 `shutdown_request` 后，自动调用 `shutdown_response` 工具并退出。

**协议2：Plan Approval**

```
Teammate                 Lead
  | plan_approve →      |（收到计划，展示给用户）
  |                     | 用户批准
  | ← plan_response     |
  | 继续执行或放弃       |
```

实现：
- Teammate 调用 `plan_approve` → 发消息给 lead
- Lead 调用 `plan_approval` → 发消息回 teammate

两个协议共享同一个模式：**`request_id` 关联请求和回复**

```java
// Tracker 存请求，request_id 作为 key
Map<String, Map<String, Object>> planRequests = new ConcurrentHashMap<>();
```

### SubAgent vs Teammate

| | SubAgent (Chapter 5) | Teammate (Chapter 10) |
|--|--|--|
| 生命周期 | 一次性，用完销毁 | 持久化，长期存在 |
| 通信方式 | 直接返回结果 | 通过消息总线异步通信 |
| 状态管理 | 无 | 有 idle/working/shutdown 状态 |
| 适用场景 | 临时子任务 | 长期协作分工 |

### 踩过的坑

- **文件名大小写**：`readInbox("Lead")` 和 `send("lead", ...)` 是两个文件，必须统一
- **system prompt 必须告知通信方式**：不告诉 teammate"发消息给 lead"，模型不会主动通信
- **tool schema 必须加 `type: "function"` 包装**：不包装会导致 API 400 错误
- **AtomicBoolean 控制退出**：lambda 里不能修改外部变量，必须用 `AtomicBoolean`

### 本章学到了什么

- **MessageBus 是最简单的进程间通信**，append-only 文件实现持久化和异步
- **破坏性读取**是为了避免重复处理
- **AgentRunner 提取**让不同 Agent 复用同一套 LLM 调用逻辑
- **协议 = 约定好的消息格式 + Tracker 记录状态**

---

## Chapter 11: 多 Agent 架构总结 <a name="chapter-11"></a>

### 什么才是"真正的"多 Agent

很多人以为"能配置多个 Agent"就是多 Agent 架构。其实不是。

**假多 Agent**：多个 Agent 各自独立工作，互相不知道对方存在，各自调用同一个大模型。

**真多 Agent**：
- Agent 之间有通信机制（消息总线）
- Agent 之间有协作流程（计划审批、任务分配）
- Agent 之间有角色分工（lead、coder、reviewer）

### Agent 之间的通信模式

| 模式 | 说明 | 代表 |
|------|------|------|
| **消息总线（异步）** | 通过共享消息队列通信，Agent 完全独立 | s09 JSONL 文件 |
| **共享内存（同步）** | 共享同一上下文窗口，实时看到彼此输出 | Claude Code 多行编辑 |
| **层级通信** | Lead 协调多个 Worker，Worker 之间不直接通信 | 任务分解+并行执行 |

### 什么场景需要多 Agent

**需要：**
- 任务需要不同角色的专业能力（写代码 / 审查代码 / 部署）
- 多个子任务需要并行执行
- 需要"人"在循环中审批关键决策

**不需要：**
- 单一任务，单一工具调用
- 任务可以用单一 Agent + 工具链完成

### SubAgent 和 Teammate 的选择

| 问题 | 答案 |
|------|------|
| 任务需要返回结果吗？ | 需要 → SubAgent；不需要 → 后台任务 |
| 需要多个 Agent 同时跑吗？ | 是 → Teammate；否 → SubAgent |
| Agent 需要持久存在吗？ | 是 → Teammate；否 → SubAgent |
| Agent 之间需要通信吗？ | 是 → Teammate；否 → SubAgent |

### 从简单开始

不要一开始就设计复杂的多 Agent 系统：

```
基础循环 → 加工具 → 加 SubAgent → 加后台任务 → 加多 Agent
```

每一层都是在解决真实问题，而不是为了"架构"而加架构。

---

## 附录：术语对照 <a name="appendix"></a>

| 英文 | 中文 | 解释 |
|------|------|------|
| Agent | Agent | 能自主决策并执行动作的智能体 |
| Harness | 载具 | 让 Agent 跑起来的工程基础设施 |
| Tool | 工具 | Agent 能执行的动作 |
| Handler | 处理器 | 执行工具的代码 |
| Dispatcher | 分发器 | 根据工具名找到对应 Handler |
| SubAgent | 子 Agent | 一次性、任务完成后销毁的子 Agent |
| Teammate | 队友 Agent | 持久化、长期存在的协作 Agent |
| MessageBus | 消息总线 | Agent 之间传递消息的机制 |
| Context | 上下文 | LLM 看到的完整对话历史 |
| Context Compact | 上下文压缩 | 减少历史消息长度 |
| Agent Loop | Agent 循环 | 调用 LLM → 执行工具 → 循环直到完成 |
| Notification | 通知 | 后台任务完成后的异步通知 |
| Protocol | 协议 | Agent 之间通信的约定格式 |
| request_id | 请求 ID | 关联请求和回复的唯一标识 |

---

*文档版本：v2.0，2026-04-06*
*基于 learn-claude-code 课程 + mini-agent 实战项目*
